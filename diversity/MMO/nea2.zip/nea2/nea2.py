#!/usr/bin/env python
###############################################################################
# Version: 1.1
# Last modified on: 28 September, 2016
# Developers: Simon Wessing (sampling code, NBC implementation),
#             Michael G. Epitropakis (CEC problem interface),
#             Mike Preuss (NEA2/NEA2+ specific code)
#
# uses the CMA-ES implementation of Nikolaus Hansen (imported as cma), also for
# the explicitly not tested case of 1D (therefore the warnings)
###############################################################################
import random
import time


from cec2013.cec2013 import *
import numpy as np
import cma

from evoalgos.niching import NearestBetterClustering
from optproblems import Problem, BoundConstraintsRepair, ScalingPreprocessor, Cache, Individual, ResourcesExhausted
from diversipy import maximin_reconstruction, calc_euclidean_dist_matrix


INFINITY = float("inf")


def sort_key(individual):
    """Sort key for lexicographic sorting with special treatment of None.

    None is replaced with infinity (the worst possible value).

    """
    try:
        iter(individual.objective_values)
        key = []
        for objective in individual.objective_values:
            if objective is None:
                objective = INFINITY
            key.append(objective)
    except TypeError:
        key = individual.objective_values
        if key is None:
            key = INFINITY
    return key



class Recorder:

    def __init__(self, problem):
        self.problem = problem
        self.points = []
        self.responses = []


    def __call__(self, phenome):
        obj_value = self.problem(phenome)
        self.points.append(phenome)
        self.responses.append(obj_value)
        return obj_value



############# above this line: nea2 related helper functions



# wrapper for CMA-ES
def cmaes(problem, start_point, step_size, do_stop_early, seed, max_iterations=INFINITY):
    # wrapper for cma es code
    if problem.remaining_evaluations <= 0:
        raise ResourcesExhausted()
    bounds = [problem.min_bounds, problem.max_bounds]
    if do_stop_early:
        tolfun = 1e-6
        tolfunhist = 1e-5
    else:
        tolfun = 1e-11
        tolfunhist = 0.0
    recorder = Recorder(problem)
    optionsDict = {'maxfevals': problem.remaining_evaluations,
                   "maxiter": max_iterations,
                   "bounds": bounds,
                   "tolfun": tolfun,
                   #"tolfunhist": tolfunhist,
                   "verb_time": False,
                   "verb_log": 0,
                   "verbose": -1,
                   "verb_disp": 0,
                   "seed": seed}
    try:
        # try-block because CMAES might try to slightly exceed the budget
        results = cma.fmin(recorder, start_point, step_size, options=optionsDict)
        ind = Individual(phenome=list(results[0]), objective_values=results[1])
    except (StopIteration, ValueError) as e:
        new_individuals = []
        for phenome, obj_value in zip(recorder.points, recorder.responses):
            new_individuals.append(Individual(phenome=list(phenome), 
                                              objective_values=obj_value))
        if len(new_individuals) > 0:
            ind = min(new_individuals, key=sort_key)
        else:
            ind = Individual(phenome=list(start_point), objective_values=problem(start_point))
    #print ("cmaes", start_point, step_size, problem.consumed_evaluations, ind.objective_values, ind.phenome)
    ind.found_at_eval = problem.consumed_evaluations
    ind.found_at_time = time.clock()
    return ind


# wrapper for niching competition problems
class NichingCompProblem(Problem):

    def __init__(self, function_id, normalize=True):
        self.function = CEC2013(function_id)
        self.num_variables = self.function.get_dimension()
        scaling = None
        min_bounds = [self.function.get_lbound(i) for i in range(self.num_variables)]
        max_bounds = [self.function.get_ubound(i) for i in range(self.num_variables)]
        if normalize:
            bounds = (min_bounds, max_bounds)
            unit_cube = ([0.0] * self.num_variables, [1.0] * self.num_variables)
            self.min_bounds = unit_cube[0]
            self.max_bounds = unit_cube[1]
            scaling = ScalingPreprocessor(unit_cube, bounds)
        else:
            bounds = (min_bounds, max_bounds)
            self.min_bounds = min_bounds
            self.max_bounds = max_bounds
        # before evaluations, possible constraint violations will be repaired
        repair = BoundConstraintsRepair(bounds, ["reflect"] * self.num_variables, previous_preprocessor=scaling)
        
        def negated_function(x):
            obj_value = self.function.evaluate(x)
            #print x, obj_value, self.consumed_evaluations
            if obj_value is not None:
                return -obj_value
            else:
                return obj_value
        
        Problem.__init__(self, negated_function,
                         num_objectives=1,
                         max_evaluations=self.function.get_maxfes(),
                         phenome_preprocessor=repair,
                         name="CEC2013 Niching Problem " + str(function_id))


# write to the solution table of one run in GECCO 2016 format
def write_to_file(local_opt_approximations, filename, start_time, sort_by_time=True):
    
    def time_key(ind):
        return ind.found_at_eval
        
    individuals_copy = list(local_opt_approximations)
    if sort_by_time:
        individuals_copy.sort(key=time_key)
    with open(filename, "w") as output_file:
        for ind in individuals_copy:
            line_parts = list(map(str, ind.phenome))
            line_parts.append("=")
            line_parts.append(str(ind.objective_values))
            line_parts.append("@")
            line_parts.extend(map(str, [ind.found_at_eval, (ind.found_at_time - start_time) * 1000.0]))
            line = "\t".join(line_parts)
            output_file.write(line)
            output_file.write("\n")



# main algorithm
def nea2plus(problemID, repeat, global_sample_size=400, edgeLengthFactor=1.3, usedRules=(1, 2), useEdgeLengthsForRule1Threshold=True):
    start_time = time.clock()
    problem = NichingCompProblem(problemID)
    dim = problem.num_variables
    bounds = ([0.0] * dim, [1.0] * dim)
    repair_component = BoundConstraintsRepair(bounds, ["reflect"] * dim)
    budget = problem.remaining_evaluations
    problem.archive = []

    #print budget, dim
    base_seed = 21062016
    seed = base_seed + problemID * 100 + repeat
    random.seed(seed)
    np.random.seed(seed)

    # config
    counter = 0
    unused_global_samples = []
    two_stage_iterations = 0
    local_algorithm = cmaes
    nbc = NearestBetterClustering(edge_length_factor=edgeLengthFactor, 
                                  used_rules=usedRules, 
                                  use_edge_lengths_for_threshold=useEdgeLengthsForRule1Threshold)
    started_individuals = []
    local_opt_approximations = []
    # start loop
    try:
        while problem.remaining_evaluations > global_sample_size:
            # start with a sample
            print("remaining evaluations: ", problem.remaining_evaluations, 
                  ", epochs: ", two_stage_iterations, sep="")
            global_sample = maximin_reconstruction(num_points=global_sample_size, 
                                                   dimension=dim, 
                                                   num_steps=None,
                                                   initial_points=None, 
                                                   existing_points=None, 
                                                   use_reflection_edge_correction=False,
                                                   dist_matrix_function=None, 
                                                   callback=None)
            sample_individuals = [Individual(phenome=point) for point in global_sample]
            for ind in sample_individuals:
                problem.evaluate(ind)
                ind.found_at_eval = problem.consumed_evaluations
                ind.found_at_time = time.clock()

            # do clustering to detect basins of attraction
            filtered_start_individuals = nbc.select(sample_individuals)
            filtered_start_individuals.sort(key=sort_key)

            for start_ind in filtered_start_individuals:
                tuple_start = tuple(start_ind.phenome)
                #compute the stepsize for the next
                avg_dist = 0
                for i in range(0,problem.num_variables):
                    avg_dist += (problem.max_bounds[i] - problem.min_bounds[i])**2
                #avg_dist /= problem.num_variables
                diag = math.sqrt(avg_dist)
                step_size = max( 0.025 * diag, np.random.normal(0.05 * diag, 0.025 * diag, 1)[0])

                #step_size = 0.15
                started_individuals.append(start_ind)
                opt = local_algorithm(problem, start_ind.phenome, step_size, do_stop_early=True, seed=seed + counter)
                opt.phenome = repair_component(opt.phenome)
                local_opt_approximations.append(opt)
                counter += 1

            two_stage_iterations += 1
    except StopIteration as instance:
        print(instance)

    local_opt_approximations.sort(key=sort_key)
    filtered_local_optima = local_opt_approximations
    filtered_local_optima.sort(key=sort_key)
    real_min_bounds = [problem.function.get_lbound(i) for i in range(dim)]
    real_max_bounds = [problem.function.get_ubound(i) for i in range(dim)]
    unit_cube = ([0.0] * dim, [1.0] * dim)
    scale_back = ScalingPreprocessor(unit_cube, (real_min_bounds, real_max_bounds))
    filtered_global_optima = []
    best_obj_value = float(local_opt_approximations[0].objective_values)
    for ind in filtered_local_optima:
        min_dist = INFINITY
        relevant_phenomes = [ind2.phenome for ind2 in filtered_global_optima]
        if len(relevant_phenomes) > 0:
            relevant_phenomes = np.atleast_2d(relevant_phenomes)
            distances = calc_euclidean_dist_matrix(np.atleast_2d(ind.phenome), relevant_phenomes)
            min_dist = min(min_dist, distances.min())
        if min_dist > 1e-4 and abs(float(ind.objective_values) - best_obj_value) <= 0.001:
            filtered_global_optima.append(ind)
    for ind in local_opt_approximations:
        ind.phenome = scale_back(ind.phenome)
        ind.objective_values = float(-ind.objective_values)
    print(len(local_opt_approximations), len(filtered_local_optima), len(filtered_global_optima))
    prob_id_string = "{0:{fill}3}".format(problemID, fill="0")
    repeat_string = "{0:{fill}3}".format(repeat, fill="0")
    filename = "approximation_sets/problem" + prob_id_string + "run" + repeat_string + ".dat"
    #localOptimaFile = open(filename, "w")
    write_to_file(filtered_global_optima, filename, start_time)
    write_to_file(filtered_local_optima, "approximation_sets/lokale_problem" + prob_id_string + "run" + repeat_string + ".dat", start_time, sort_by_time=False)



#######################
####################### test program stub follows

# this is going to be executed if nothing else is stated!
if __name__ == "__main__":
    #main()
    
    #f = CEC2013(7)
    #obj = f.evaluate([6.10089128554, 6.10094637735])
    #print(obj)
    #exit()
    
    #problem_id = int(sys.argv[1])
    #repeat = int(sys.argv[2])
    print("start")

    for problem_id in range(5,6):#1,21):
        for repeat in range(1,2):#51):
            nea2plus(problem_id, repeat)
    print("end")


